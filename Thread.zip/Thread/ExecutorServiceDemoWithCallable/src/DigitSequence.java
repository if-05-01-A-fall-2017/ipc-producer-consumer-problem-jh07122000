/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oca.defaultinterface;
/**
 *
 * @author Janine H
 */


public class DigitSequence implements IntSequence {
	
	private int number;
	
	public DigitSequence(int num) {
		number = num;
	}
	
	public boolean hasNext() {
		return number != 0;
	}

	/* (non-Javadoc)
	 * @see oca.defaultinterface.IntSequence#next()
	 */
	@Override
	public int next() {
		int n = number % 10;
		number /= 10;
		return n;
	}

}